// const form = document.getElementById('upload-form');
// const result = document.getElementById('result');

// form.addEventListener('submit', async (event) => {
//   event.preventDefault();
//   result.innerHTML = '';
//   result.style.display = 'none';

//   const formData = new FormData(form);
//   const response = await fetch('/compress', {
//     method: 'POST',
//     body: formData,
//   });

//   if (response.ok) {
//     const blob = await response.blob();
//     const url = URL.createObjectURL(blob);
//     const img = document.createElement('img');
//     img.src = url;
//     result.appendChild(img);
//     result.style.display = 'block';
//   } else {
//     const error = await response.text();
//     alert(`Error: ${error}`);
//   }
// });

const form = document.getElementById('upload-form');
const resultsDiv = document.getElementById('results');

form.addEventListener('submit', async (event) => {
  event.preventDefault();

  const formData = new FormData(form);
  const response = await fetch('/compress', {
    method: 'POST',
    body: formData
  });
  const results = await response.json();

  resultsDiv.innerHTML = '';
  results.forEach((result) => {
    const img = document.createElement('img');
    img.src = URL.createObjectURL(new Blob([result.buffer]));
    resultsDiv.appendChild(img);
  });
});