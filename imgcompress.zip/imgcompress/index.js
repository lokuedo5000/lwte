// Shar3G v 1.0.0

// Electron
const {
  app,
  BrowserWindow,
  webContents,
  Menu,
  ipcMain,
  screen,
  dialog,
  session,
  Notification,
  nativeTheme,
  shell,
} = require("electron");

const ProgressBar = require("electron-progressbar");

app.commandLine.appendSwitch("disable-web-security");

// importar ejs
const ejs = require("ejs");

// Aqui los otros Modules
const url = require("url");
const path = require("path");
const fs = require("fs");
const https = require("https");

// save data window
const WindowStateManager = require("electron-window-state-manager");

// module server
const expressApp = require(path.join(
  __dirname,
  "modules",
  "server",
  "server.js"
));

//   port
let port = 3020;

// server creator
var startServer = async function () {
  // crear server
  await expressApp
    .listen(port, () => {
      // newMS('server', true);
    })
    .on("error", (err) => {
      // newMS('server', false);
    });

  // return showMS('server');
};

// theme
nativeTheme.on("updated", () => {
  if (nativeTheme.shouldUseDarkColors) {
    // set theme
    // nativeTheme.themeSource = "dark";
  } else {
    // set theme
    // nativeTheme.themeSource = "light";
  }
});

let win;

// Función para cerrar y reiniciar la aplicación
function restartApp() {
  app.relaunch();
  app.quit();
}

// ready electron
app.on("ready", async () => {
  // iniciar server
  await startServer();

  // set theme
  nativeTheme.themeSource = "dark";

  // setAppUserModelId
  if (process.platform === "win32") {
    app.setAppUserModelId("app.lwte.shareg");
  }

  /*Abrir ventana por tamaño default*/
  const winState = new WindowStateManager("win", {
    defaultWidth: 500,
    defaultHeight: 500,
  });
  /*Datos de la ventana*/
  win = new BrowserWindow({
    icon: path.join(__dirname, "assets", "icons", "win", "icoShar3G.ico"),
    width: winState.width,
    height: winState.height,
    minWidth: 500,
    minHeight: 500,
    x: winState.x,
    y: winState.y,
    title: "Lwte.dev",
    titleBarStyle: "customButtonsOnHover",
    // transparent: true,
    // maximizable: true,
    // resizable: true,
    // frame: false,
    show: false,
    webPreferences: {
      nodeIntegration: true, // is default value after Electron v5
      contextIsolation: false, // protect against prototype pollution
      enableRemoteModule: true, // turn off remote
      // webSecurity: true,
      preload: path.join(
        __dirname,
        "reload",
        "win.js"
      ) /* Archivo Preloader /script/reload/win.js */,
    },
  });

  /*Add Menu*/
  const menuMainWindow = Menu.buildFromTemplate(templateMenu);
  win.setMenu(menuMainWindow);
  win.setMenuBarVisibility(false);

  // Mediante este evento muestra la ventana principal cuando está cargada y lista para mostrar
  win.once("ready-to-show", () => {
    win.show();

    // id ventana
    win.id_ventana = "ventana_madre";
  });

  /*Load Url*/
  win.loadURL("http://" + "localhost" + ":" + port + "/");
  win.on("close", () => {
    winState.saveState(win);
    // app.quit();
  });

  /*Verifica si la Ventana fue cerrada maximizada*/
  if (winState.maximized) {
    win.maximize();
  }
});

// apps home
ipcMain.on("openhomes", (event, ruta) => {
  // open package
  const pkruta = path.resolve("./", "package.json");
  const pktext = fs.readFileSync(pkruta, "utf-8");
  let pk = JSON.parse(pktext);

  // new data
  // pk.main = "main/main.js";
  pk.scrindex = "main/home.js";
  // pk.scripts.start = "electron ./main/main.js";

  // save data
  fs.writeFileSync(pkruta, JSON.stringify(pk, null, 2), "utf-8");

  // restart
  setTimeout(() => {
    restartApp();
  }, 2000);
});
// end

ipcMain.on("ruta-archivo", (event, ruta) => {
  event.reply("ruta-archivo", ruta);
});

// newventana
ipcMain.on("newventana", (event, datos) => {
  // id ventana
  let ventana_id =
    "ventana_" + parseInt(BrowserWindow.getAllWindows().length) + parseInt(1);

  /*Abrir ventana por tamaño default*/
  const winState = new WindowStateManager(ventana_id, {
    defaultWidth: 500,
    defaultHeight: 500,
  });
  /*Datos de la ventana*/
  ventana_id = new BrowserWindow({
    icon: path.join(__dirname, "assets", "icons", "win", "icoShar3G.ico"),
    width: winState.width,
    height: winState.height,
    minWidth: 500,
    minHeight: 500,
    x: winState.x,
    y: winState.y,
    title: "Lwte.dev",
    titleBarStyle: "customButtonsOnHover",
    // transparent: true,
    // maximizable: true,
    // resizable: true,
    // frame: false,
    show: false,
    webPreferences: {
      nodeIntegration: true, // is default value after Electron v5
      contextIsolation: false, // protect against prototype pollution
      enableRemoteModule: true, // turn off remote
      // webSecurity: true,
      // preload: path.join(__dirname, 'reload', 'win.js') /* Archivo Preloader /script/reload/win.js */
    },
  });

  /*Add Menu*/
  const menuMainWindow = Menu.buildFromTemplate(templateMenu);
  ventana_id.setMenu(menuMainWindow);
  ventana_id.setMenuBarVisibility(false);

  // Mediante este evento muestra la ventana principal cuando está cargada y lista para mostrar
  ventana_id.once("ready-to-show", () => {
    ventana_id.show();
  });

  /*Load Url*/
  ventana_id.loadURL("http://" + "localhost" + ":" + port + "/" + datos);
  ventana_id.on("close", () => {
    winState.saveState(win);
  });

  /*Verifica si la Ventana fue cerrada maximizada*/
  if (winState.maximized) {
    ventana_id.maximize();
  }
});

/*Menu Clear*/
Menu.setApplicationMenu(null);

/*Menu*/
var templateMenu = [
  {
    role: "reload",
  },
  {
    label: "Update",
    accelerator: process.platform == "darwin" ? "Comand+alt+R" : "Ctrl+alt+R",
    click() {
      app.relaunch();
      app.quit();
      //win.webContents.send('reset-app', 'end');
    },
  },
];

// Reload in Development for Browser Windows
var DevTools = process.env.APP_DEV
  ? process.env.APP_DEV.trim() == "true"
  : true;

if (DevTools) {
  templateMenu.push({
    label: "DevTools",
    submenu: [
      {
        label: "Show/Hide Dev Tools",
        accelerator: process.platform == "darwin" ? "Comand+D" : "Ctrl+D",
        click(item, focusedWindow) {
          focusedWindow.toggleDevTools();
        },
      },
    ],
  });
}
