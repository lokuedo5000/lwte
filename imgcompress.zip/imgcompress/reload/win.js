const { ipcRenderer } = require("electron");
const path = require("path");
const internal = require("stream");

window.addEventListener("DOMContentLoaded", () => {
  ipcRenderer.on("bar-run", (event, data) => {
    // show progreso
    const show_progress = document.querySelector(".bar_progress");
    show_progress.style.display = "block";
    show_progress.classList.add("mostrar");

    // run progreso
    const barr = document.querySelector(".bar_run");
    barr.style.width = data + "%";

    // verificar 100%
    if (data === 100) {
      setTimeout(function () {
        show_progress.style.display = "none";
        show_progress.classList.remove("mostrar");
      }, 3000);
    }
  });
  ipcRenderer.on("ruta-archivo", (event, ruta) => {
    var list_img_view = document.querySelector(".listaimg_text");
    list_img_view.innerHTML = "";

    for (let a = 0; a < ruta.length; a++) {
      // Ruta del archivo
      const absolutePath = path.resolve(ruta[a].file);

      // extension
      const extension = path.extname(ruta[a].file);

      // elegir color
      var color = "blue lighten-5";
      if (extension == ".png") {
        color = "blue";
      } else if (extension == ".jpg") {
        color = "red";
      } else if (extension == ".jpeg") {
        color = "red";
      }

      // console.log(ruta[a].file);
      list_img_view.innerHTML += `<li data-id="id_img_${a}_num">
                                    <div class="collapsible-header">
                                      <i class="material-icons id_img_${a}_num">access_time</i>
                                      ${ruta[a].name}
                                      <span class="new badge ${color}" data-badge-caption="${ruta[a].type}"></span></div>
                                    <div class="collapsible-body">
                                     
                                     <div class="sprt">
                                      <h5>Ruta de origen del archivo</h5>
                                      <h6>${absolutePath}</h6>
                                     </div>

                                     <div class="sprt img_result none-div">
                                      <h5>Resultado</h5>
                                      <div class="img_view">
                                      
                                      </div>
                                     </div>
                                    
                                    </div>
                                  </li>`;
    }
  });
});
