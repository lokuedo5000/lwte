// node js
const { BrowserWindow, webContents } = require("electron");

// module
const express = require("express");
const app = express();
const path = require("path");
const fs = require("fs");

// db
const { initDB, setData } = require(path.join(
  __dirname,
  "../",
  "datadb",
  "datadb.js"
));

const sharp = require("sharp");
const async = require("async");
const multer = require("multer");

const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    const dir = path.join(__dirname, "temps");

    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir);
    }

    cb(null, dir);
  },
  filename: function (req, file, cb) {
    cb(null, Date.now() + "-" + file.originalname);
  },
});

const upload = multer({ storage: storage });

// const upload = multer({ dest: path.join(__dirname, "upload") });

// Middleware para parsear el cuerpo de las peticiones HTTP
app.use(express.urlencoded({ extended: true }));
app.use(express.json());

// Configuración de la plantilla EJS
app.set("view engine", "ejs");
app.set("views", path.join(__dirname, "views"));
app.use(express.static(path.join(__dirname, "public")));

// Rutas
app.get("/", (req, res) => {
  res.render(path.join(__dirname, "views", "index"), {
    title: "Mi sitio web",
  });
});

// verificar base de datos
initDB(path.join(__dirname, "../../", "json"), "imgcompess", "compressed[]");
// end

// get size img of list json
async function getFilesizeInBytes(filename) {
  var stats = fs.statSync(filename);
  var fileSizeInBytes = stats.size;
  return fileSizeInBytes;
}

// upload
app.post("/upload", upload.array("images"), async function (req, res) {
  const files = req.files;
  const totalImages = files.length;
  let completedImages = 0;
  const tasks = [];

  // lista de imagenes
  let list_img = [];

  // datos de los archivos
  let infoall = [{ totalIMG: files }, { Total: totalImages }];

  const promises = files.map((file) => {
    return new Promise((resolve, reject) => {
      sharp(file.path)
        .png({ compressionLevel: 9 })
        .jpeg({ quality: 80 })
        .toFile(
          __dirname + "/public/uploads/" + file.filename,
          async function (err) {
            if (err) {
              reject(err);
            } else {
              completedImages++;
              const progress = (completedImages / totalImages) * 100;

              // Object
              let obj = {
                name: file.filename,
                path: "/uploads/" + file.filename,
                progress: 100,
                classe: completedImages,
                sizeimg: await getFilesizeInBytes(
                  path.join(__dirname, "public", "uploads", file.filename)
                ),
              };

              // agregar las imagenes a la lista de imagenes comprimidas
              setData(
                path.join(__dirname, "../../", "json"),
                "imgcompess",
                "compressed[]",
                obj
              );

              // add list
              list_img.push(obj);

              // end

              // await console.log(progress);

              resolve(progress);
            }
          }
        );
    });
  });

  try {
    const progressArray = await Promise.all(promises);
    const progress =
      progressArray.reduce((a, b) => a + b, 0) / progressArray.length;

    res.send({ statusac: "done", imglist: list_img });

    // Eliminar archivos temporales
    fs.readdir(path.join(__dirname, "temps"), (err, files) => {
      if (err) throw err;
      for (const file of files) {
        fs.unlink(path.join(__dirname, "temps", file), (err) => {
          if (err) throw err;
        });
      }
    }); 
  } catch (err) {
    throw err;
  }
});

// download
app.get("/download/:file", function (req, res) {
  
  // ventana
  let allventanas = BrowserWindow.getAllWindows();
  // datos file
  let params = req.params;
  let filePath = path.join(__dirname, "public", "uploads", params.file);

  // verificar si el archivo existe antes de descargarlo
  if (!fs.existsSync(filePath)) {
    res.status(404).send("Archivo no encontrado");
    return;
  }

  // establecer el encabezado de respuesta de descarga
  res.setHeader("Content-disposition", "attachment; filename=" + params.file);

  // verificar el tipo de contenido y establecer el encabezado apropiado
  if (path.extname(filePath) === ".jpeg" || path.extname(filePath) === ".jpg") {
    res.setHeader("Content-type", "image/jpeg");
  } else if (path.extname(filePath) === ".png") {
    res.setHeader("Content-type", "image/png");
  } else {
    res.status(400).send("Tipo de imagen no admitido");
    return;
  }

  // abrir el archivo y crear un flujo de lectura
  var fileStream = fs.createReadStream(filePath);

  // enviar el archivo al navegador para descargar
  fileStream.pipe(res);

  // manejar eventos de progreso mientras se está descargando el archivo
  fileStream.on("open", function () {
    // console.log("Comenzando descarga...");
  });

  var totalBytes = fs.statSync(filePath).size;
  var bytesSent = 0;
 
  fileStream.on("data", function (chunk) {
    bytesSent += chunk.length;
    var progress = (bytesSent / totalBytes) * 100;

    // send progress
    allventanas.forEach((id) => {
      if (id.id_ventana) {
        if (id.id_ventana == "ventana_madre") {
          id.webContents.send("bar-run", progress.toFixed(2));
        }
      }
    });
  });

  res.on("finish", function () {
    // send progress
    allventanas.forEach((id) => {
      if (id.id_ventana) {
        if (id.id_ventana == "ventana_madre") {
          id.webContents.send("bar-run", 100);
        }
      }
    });

    // show img
    
  });
});

// Manejo de errores 404
app.use((req, res, next) => {
  const error = new Error("No se encontró la página solicitada");
  error.status = 404;
  next(error);
});

// Manejo de errores generales
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(err.status || 500);
  res.render(path.join(__dirname, "views", "error"), {
    title: "Error",
    message: err.message,
  });
});

// Exportamos el servidor Express
module.exports = app;
