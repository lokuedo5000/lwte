// node js
const { ipcRenderer } = require("electron");

const path = require("path");
const fs = require("fs");

// lodash
const _ = require("lodash");

// db
const { initDB, setData, loadData } = require(path.resolve(
  "./",
  "main",
  "apps",
  "imgcompress",
  "modules",
  "datadb"
));

if (
  window.matchMedia &&
  window.matchMedia("(prefers-color-scheme: dark)").matches
) {
  // Theme Dark
  const menu_color = document.querySelectorAll(".theme_bg");

  menu_color.forEach((elems) => {
    elems.classList.add("grey", "darken-4");
  });

  // body
  const body_color = document.querySelector("body");
  body_color.classList.add("grey", "lighten-3");
} else {
  // El tema claro está activado
}

// open files
function fsopen(paths, types, obj) {
  if (types) {
    if (types == "write") {
      if (obj) {
        try {
          fs.writeFileSync(paths, JSON.stringify(obj, null, 2), "utf-8");
          return true;
        } catch (err) {
          console.log(err);
          return false;
        }
      }
    }
  } else {
    // open file
    const fileruta = path.resolve(paths);

    // verificar si no hay errores
    try {
      const datos = fs.readFileSync(fileruta, "utf-8");
      return JSON.parse(datos);
    } catch (error) {
      return false;
    }
  }
}

// eliminator Array
function arrayDelete(array, obj, id) {
  const index = array.findIndex((elemento) => elemento[obj] === id);
  if (index !== -1) {
    return [...array.slice(0, index), ...array.slice(index + 1)];
  }
  return array;
}

// delete img
function imgdlt(data) {
  const filePath = path.resolve(data);

  if (fs.existsSync(filePath)) {
    try {
      fs.unlinkSync(filePath);
      return true;
    } catch (err) {
      return false;
    }
  } else {
    return false;
  }
}

//   get data imgs
const input = document.getElementById("images");

// list files
let listfiles = [];
input.addEventListener("change", (event) => {
  listfiles.length = 0;
  const files = event.target.files;

  // add list views
  for (let i = 0; i < files.length; i++) {
    listfiles.push({
      name: files[i].name,
      file: files[i].path,
      type: files[i].type,
    });
  }

  // add array
  listfiles.push(files);

  // delete last
  listfiles.pop();

  // verificar la cantidad

  if (listfiles.length > 10) {
    // si pasa el maximo
    document.querySelector(".btn_compress").classList.add("disabled");
  } else {
    // enviar datos
    ipcRenderer.send("ruta-archivo", listfiles);

    // verificado
    document.querySelector(".btn_compress").classList.remove("disabled");
  }
});

// enviar
document.querySelector(".btn_compress").addEventListener("click", function () {
  document.querySelector(".btn_env").click();
});

// function list
function getSize(num) {
  const units = ["B", "kB", "MB", "GB", "TB", "PB", "EB", "ZB", "YB"];
  const neg = num < 0;
  if (neg) num = -num;
  if (num < 1) return (neg ? "-" : "") + num + " B";
  const exponent = Math.min(
    Math.floor(Math.log(num) / Math.log(1000)),
    units.length - 1
  );
  const unit = units[exponent];
  num = Number((num / Math.pow(1000, exponent)).toFixed(2));
  return (neg ? "-" : "") + num + " " + unit;
}

$(document).ready(function () {
  $("form").submit(function (event) {
    event.preventDefault();
    $.ajax({
      url: "/upload",
      type: "POST",
      data: new FormData($("form")[0]),
      processData: false,
      contentType: false,
      success: function (data) {
        if (data.statusac == "done") {
          // done all img
          const data_list = document.getElementById("id_list").children;

          for (let index = 0; index < data_list.length; index++) {
            data_list[index].children[0].children[0].innerHTML = "check_circle";

            // add img
            data_list[
              index
            ].children[1].children[1].children[1].innerHTML = `<img class="materialboxed" data-caption="Size: ${getSize(
              data.imglist[index].sizeimg
            )} - (<a href='/download/${
              data.imglist[index].name
            }'>Download</a>)" width="250" src="${data.imglist[index].path}">`;

            // open Resultado
            data_list[index].children[1].children[1].classList.remove(
              "none-div"
            );
          }

          // init materialboxed
          $(".materialboxed").materialbox();

          // disabled submit
          document.querySelector(".btn_compress").classList.add("disabled");

          // clear form
          document.getElementById("upload-form").reset();
        }
      },
    });
  });
});

// open download
function openhome() {
  ipcRenderer.send("openhomes", true);
}

// load img compress
function loadcompress() {
  let datajon = loadData(
    path.resolve("./", "main", "apps", "imgcompress", "json"),
    "imgcompess",
    "compressed[]"
  ).compressed;

  // verificación para saber si hay imagenes Comprimidas
  if (datajon.length > 0) {
    $(".no_img_ga").addClass("none-div");
    $(".galeria_img").removeClass("none-div");
  } else {
    $(".no_img_ga").removeClass("none-div");
    $(".galeria_img").addClass("none-div");
  }

  // div imgs
  const imgloads = document.querySelector(".garelia_all");
  imgloads.innerHTML = "";
  // cargar imagenes
  for (let index = 0; index < datajon.length; index++) {
    const element = datajon[index];
    imgloads.innerHTML += `
    <div class="col s3 m3">
          <img class="materialboxed" height="300" width="100%" data-caption="Size: ${getSize(
            element.sizeimg
          )} - (<a href='/download/${element.name}'>Download</a>)" src="${
      element.path
    }">
        </div>
    `;
  }

  // init materialboxed
  $(".materialboxed").materialbox({
    onOpenStart: function () {
      console.log("onOpenStart");
    },
    onOpenEnd: function () {
      console.log("onOpenEnd");
    },
    onCloseStart: function () {
      console.log("onCloseStart");
    },
    onCloseEnd: function () {
      console.log("onCloseEnd");
    },
  });
}

// name
function getname(name) {
  var text = name;
  var index = text.indexOf("-"); // encuentra la posición del primer guión
  var result = text.substring(0, index + 1); // selecciona la porción del string desde el primer carácter hasta la posición del primer guión, incluyendo el guión
  var remaining = text.substring(index + 1); // selecciona la porción del string desde la posición siguiente al guión hasta el final del string
  return remaining;
}

// Historial
function loadhistory() {
  // imgcompess
  let datajon = loadData(
    path.resolve("./", "main", "apps", "imgcompress", "json"),
    "imgcompess",
    "compressed[]"
  ).compressed;

  // verificación para saber si hay imagenes Comprimidas
  if (datajon.length > 0) {
    $(".no_img_history").addClass("none-div");
    $(".no_img_his").removeClass("none-div");
  } else {
    $(".no_img_history").removeClass("none-div");
    $(".no_img_his").addClass("none-div");
  }

  // html
  const imgloads = document.querySelector(".list-history");
  imgloads.innerHTML = "";

  // cargar imagenes
  for (let index = 0; index < datajon.length; index++) {
    const element = datajon[index];
    imgloads.innerHTML += `
                <li class="collection-item avatar ${element.classe}-dlt">
                  <img src="${element.path}" alt="" class="circle">
                  <span class="title">${getname(element.name)}</span>
                  <p>Original: <a href="#">${getname(
                    element.name
                  )}</a> - ${getSize(element.sizeimgbefored)}<br>
                     Comprimida: <a href="/download/${element.name}">${
      element.path
    }</a> - ${getSize(element.sizeimg)}
                  </p>
                  <a href="#!" class="dropdown-trigger secondary-content" data-target='historyimg_${index}'><i class="material-icons">keyboard_arrow_down</i></a>
                  <!-- Dropdown Structure -->
                  <ul id='historyimg_${index}' class='dropdown-content dropdown-content_app_history'>
                  <li><a href="#!" onclick="deleteimg('${
                    element.classe
                  }')">Eliminar</a></li>
                  </ul>
                </li>
    `;
  }

  // dropdown
  $(".dropdown-trigger").dropdown({
    alignment: "right",
    constrainWidth: false,
  });
}

// delete
function deleteimg(data) {
  // Desinstalar una app
  let jsonfile = fsopen("./main/apps/imgcompress/json/imgcompess.json");

  const filtered = _.filter(jsonfile.compressed, { classe: data });

  // select delete
  jsonfile.compressed = jsonfile.compressed.filter(function (element) {
    return element.classe !== filtered[0].classe;
  });

  // save
  const issave = fsopen(
    "./main/apps/imgcompress/json/imgcompess.json",
    "write",
    jsonfile
  );

  if (issave) {
    $("." + data + "-dlt").fadeOut("fast", function () {
      const deleteinupload = imgdlt(
        "./main/apps/imgcompress/modules/server/public/uploads/" +
          filtered[0].name
      );

      // temporales
      if (deleteinupload) {
        imgdlt(
          "./main/apps/imgcompress/modules/server/temps/" + filtered[0].name
        );

        // verificar si hay elementos
        if (jsonfile.compressed.length == 0) {
          $(".no_img_history").removeClass("none-div");
          $(".no_img_his").addClass("none-div");
        }
      }
    });
  }
}
