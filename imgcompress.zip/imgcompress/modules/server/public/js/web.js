// node js
const { ipcRenderer } = require("electron");

const path = require("path");
const fs = require("fs");

// db
const { initDB, setData, loadData } = require(path.resolve(
  "./",
  "main",
  "apps",
  "imgcompress",
  "modules",
  "datadb"
));

if (
  window.matchMedia &&
  window.matchMedia("(prefers-color-scheme: dark)").matches
) {
  // Theme Dark
  const menu_color = document.querySelectorAll(".theme_bg");

  menu_color.forEach((elems) => {
    elems.classList.add("grey", "darken-4");
  });

  // body
  const body_color = document.querySelector("body");
  body_color.classList.add("grey", "lighten-3");
} else {
  // El tema claro está activado
}

//   get data imgs
const input = document.getElementById("images");

// list files
let listfiles = [];
input.addEventListener("change", () => {
  listfiles.length = 0;
  // // ipcRenderer.send("ruta-archivo", input.files);
  // console.log(input.files.FileList);

  const files = event.target.files;

  // console.log(files);
  // ipcRenderer.send("ruta-archivo", files);

  // add list views
  for (let i = 0; i < files.length; i++) {
    listfiles.push({
      name: files[i].name,
      file: files[i].path,
      type: files[i].type,
    });
  }

  // add array
  listfiles.push(files);

  // delete last
  listfiles.pop();

  // verificar la cantidad

  if (listfiles.length > 10) {
    // si pasa el maximo
    document.querySelector(".btn_compress").classList.add("disabled");
  } else {
    // enviar datos
    ipcRenderer.send("ruta-archivo", listfiles);

    // verificado
    document.querySelector(".btn_compress").classList.remove("disabled");
  }
});

// enviar
document.querySelector(".btn_compress").addEventListener("click", function () {
  document.querySelector(".btn_env").click();
});

// function list
function getSize(num) {
  const units = ["B", "kB", "MB", "GB", "TB", "PB", "EB", "ZB", "YB"];
  const neg = num < 0;
  if (neg) num = -num;
  if (num < 1) return (neg ? "-" : "") + num + " B";
  const exponent = Math.min(
    Math.floor(Math.log(num) / Math.log(1000)),
    units.length - 1
  );
  const unit = units[exponent];
  num = Number((num / Math.pow(1000, exponent)).toFixed(2));
  return (neg ? "-" : "") + num + " " + unit;
}

$(document).ready(function () {
  $("form").submit(function (event) {
    event.preventDefault();
    $.ajax({
      url: "/upload",
      type: "POST",
      data: new FormData($("form")[0]),
      processData: false,
      contentType: false,
      success: function (data) {
        if (data.statusac == "done") {
          console.log(data);
          // done all img
          const data_list = document.getElementById("id_list").children;

          for (let index = 0; index < data_list.length; index++) {
            data_list[index].children[0].children[0].innerHTML = "check_circle";

            // add img
            data_list[
              index
            ].children[1].children[1].children[1].innerHTML = `<img class="materialboxed" data-caption="Size: ${getSize(
              data.imglist[index].sizeimg
            )} - (<a href='/download/${
              data.imglist[index].name
            }'>Download</a>)" width="250" src="${data.imglist[index].path}">`;
          }

          // init materialboxed
          $(".materialboxed").materialbox();

          // disabled submit
          document.querySelector(".btn_compress").classList.add("disabled");
        }
      },
    });
  });
});

// open download
function openhome() {
  ipcRenderer.send("openhomes", true);
}

// load img compress
function loadcompress() {
  let datajon = loadData(
    path.resolve("./", "main", "apps", "imgcompress", "json"),
    "imgcompess",
    "compressed[]"
  ).compressed;

  // div imgs
  const imgloads = document.querySelector(".garelia_all");
  imgloads.innerHTML = "";
  // cargar imagenes
  for (let index = 0; index < datajon.length; index++) {
    const element = datajon[index];
    imgloads.innerHTML += `
    <div class="col s3 m3">
          <img class="materialboxed" height="300" width="100%" data-caption="A picture of a way with a group of trees in a park" src="${element.path}">
        </div>
    `;
  }

  // init materialboxed
  $(".materialboxed").materialbox({
    onOpenStart: function () {
      console.log("onOpenStart");
    },
    onOpenEnd: function () {
      console.log("onOpenEnd");
    },
    onCloseStart: function () {
      console.log("onCloseStart");
    },
    onCloseEnd: function () {
      console.log("onCloseEnd");
    },
  });
}
