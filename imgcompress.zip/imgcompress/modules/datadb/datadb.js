const path = require("path");
const fs = require("fs");

// const db = low(path.join(__dirname, '../../', 'json', 'data.json'));

// verificar files json
function initDB(paths, file, table) {
  const dbPath = path.join(paths, `${file}.json`);
  const exists = fs.existsSync(dbPath);

  if (exists == false) {
    // Construimos la cadena JSON completa

    // Utilizamos una expresión regular para buscar "[]" o "{}" en la cadena
    if (/\[\]/.test(table)) {
      var resultJson = JSON.stringify({ [table.replace(/\[\]$/, "")]: [] });
    } else if (/\{\}/.test(table)) {
      var resultJson = JSON.stringify({
        [table.replace(/[{}]/g, "")]: {},
      });
    }

    try {
      fs.writeFileSync(dbPath, `${resultJson}`, "utf-8");
    } catch (error) {
      console.log(error);
    }
  }
}

// memoria temporal de guardado
let list = { compressed: [] };

// add data
function setData(paths, file, table, objects) {
  const dbPath = path.join(paths, `${file}.json`);
  const dataJson = fs.readFileSync(dbPath, "utf-8");

  let jsonObject = JSON.parse(dataJson);

  // Utilizamos una expresión regular para buscar "[]" o "{}" en la cadena
  if (/\[\]/.test(table)) {
    // Verifica si la tabla existe en el objeto JSON
    if (jsonObject.hasOwnProperty(`${table.replace(/\[\]$/, "")}`)) {
      list = jsonObject;

      list[table.replace(/\[\]$/, "")].push(objects);

      try {
        fs.writeFileSync(dbPath, JSON.stringify(list, null, 2), "utf-8");
      } catch (error) {}
    } else {
    }
  } else if (/\{\}/.test(table)) {
    // Verifica si la tabla existe en el objeto JSON
    if (jsonObject.hasOwnProperty(`${table.replace(/\{\}$/, "")}`)) {
      list = jsonObject;

      list[table.replace(/\{\}$/, "")] = objects;

      try {
        fs.writeFileSync(dbPath, JSON.stringify(list, null, 2), "utf-8");
      } catch (error) {}
    } else {
    }
  }

  // console.log(list);
}

// load datas
function loadData(paths, file, table) {
  const dbPath = path.join(paths, `${file}.json`);
  const dataJson = fs.readFileSync(dbPath, "utf-8");

  let jsonObject = JSON.parse(dataJson);

  // Utilizamos una expresión regular para buscar "[]" o "{}" en la cadena
  if (/\[\]/.test(table)) {
    // Verifica si la tabla existe en el objeto JSON
    if (jsonObject.hasOwnProperty(`${table.replace(/\[\]$/, "")}`)) {
      return jsonObject;
    } else {
      return false;
    }
  } else if (/\{\}/.test(table)) {
    // Verifica si la tabla existe en el objeto JSON
    if (jsonObject.hasOwnProperty(`${table.replace(/\{\}$/, "")}`)) {
      return jsonObject;
    } else {
      return false;
    }
  }
}

// class Database {
//   static init(paths, file, table) {
//     createDB(paths, file, table);
//   }

//   static setData(paths, file, table, objects) {
//     // lista
//     let list = [];
//     // archivo json
//     const dbPath = path.join(paths, `${file}.json`);

//     // verificar si existe la table
//     const dataJson = fs.readFileSync(dbPath, "utf-8");

//     // Parsea el contenido JSON
//     let jsonObject = JSON.parse(dataJson);
//     // add list
//     jsonObject[table].push(objects);
//     // console.log(jsonObject);
//     // save
//     fs.writeFile(dbPath, JSON.stringify(jsonObject, null, 2));
//   }

//   // static getAll(table) {
//   //   return db.get(table).value();
//   // }

//   // static getById(table, id) {
//   //   return db.get(table).find({ id }).value();
//   // }

//   // static create(table, data) {
//   //   return db.get(table).push({ id: Date.now(), ...data }).write();
//   // }

//   // static updateById(table, id, data) {
//   //   return db.get(table).find({ id }).assign(data).write();
//   // }

//   // static deleteById(table, id) {
//   //   return db.get(table).remove({ id }).write();
//   // }
// }

module.exports = { initDB, setData, loadData };
